package ElementLocator;

import org.openqa.selenium.By;

public class ElementLocator 
{
		public static By RegisterTitle=By.xpath("//h2[text()=' Conference Registration ']");
		public static By Title=By.xpath("//h4[text()=' Step 1: Personal Details ']");
		public static By firstName=By.id("txtFirstName");
		public static By bookButton=By.xpath("/html/body/form/table/tbody/tr[14]/td/a");
		public static By lastName=By.id("txtLastName");
		public static By email=By.id("txtEmail");
		public static By contact=By.id("txtPhone");
		public static By address=By.xpath("/html/body/form/table/tbody/tr[6]/td");
		public static By building=By.id("txtAddress1");
		public static By area=By.id("txtAddress2");
		public static By city=By.xpath("//select[@name='city']");
		public static By state=By.xpath("//select[@name='state']");
		public static By conference=By.xpath("//input[@value='member']");
		public static By cardHolderName=By.id("txtCardholderName");
		public static By cardNumber=By.id("txtDebit");
		public static By cvv=By.id("txtCvv");
		public static By expiryMon=By.id("txtMonth");
		public static By expiryYear=By.id("txtYear");
		public static By button=By.id("btnPayment");
		public static By persons=By.xpath("//select[@name='size']");
}


