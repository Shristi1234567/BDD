package StepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdefinition {

	@Given("^Conference Registration$")
	public void conference_Registration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.openbrowser();
	}
	@When("^user come to registration page$")
	public void user_come_to_registration_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.linkOpenLogin("file:///C:/Users/shimmats/Pictures/M4%20set1%20webpages/ConferenceRegistartion.html#");
	}

	@When("^user validate FirstName$")
	public void user_validate_FirstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.insertKeys("Shristi",ElementLocator.ElementLocator.firstName);
		Thread.sleep(3000);
	}

	@When("^user validate LastName$")
	public void user_validate_LastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.insertKeys("Himmat",ElementLocator.ElementLocator.lastName);
		Thread.sleep(3000);
	}

	@When("^user validate Email$")
	public void user_validate_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.insertKeys("shristihimmat",ElementLocator.ElementLocator.email);
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.clearBox(ElementLocator.ElementLocator.email);
		PageFact.PageFactory.insertKeys("shristihimmat@gmail.com",ElementLocator.ElementLocator.email);
		Thread.sleep(3000);
	}

	@When("^user validate Contact no$")
	public void user_validate_Contact_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.insertKeys("1234",ElementLocator.ElementLocator.contact);
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.clearBox(ElementLocator.ElementLocator.contact);
		PageFact.PageFactory.insertKeys("9879879879",ElementLocator.ElementLocator.contact);
	}

	@When("^user select number of people attending$")
	public void user_select_number_of_people_attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.select(ElementLocator.ElementLocator.persons);
	}

	@When("^user validate Address$")
	public void user_validate_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//PageFact.PageFactory.insertKeys("Capgemini",ElementLocator.ElementLocator.address);
	}

	@When("^user enters Building Name and Room No$")
	public void user_enters_Building_Name_and_Room_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.insertKeys("Capgemini",ElementLocator.ElementLocator.building);
	}

	@When("^user enters Area Name$")
	public void user_enters_Area_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.insertKeys("Sipcot",ElementLocator.ElementLocator.area);
	}

	@When("^user select city$")
	public void user_select_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.select(ElementLocator.ElementLocator.city);
	}

	@When("^user select state$")
	public void user_select_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.select(ElementLocator.ElementLocator.state);
	}

	@When("^user select Conference full-Access$")
	public void user_select_Conference_full_Access() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		System.out.println("conference");
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.select2(ElementLocator.ElementLocator.conference);
		
	}
	
	@Then("^click on next buton$")
	public void click_on_next_buton() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.bookButton);
		PageFact.PageFactory.alertHandler();
	}
	@Given("^payment page$")
	public void payment_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//PageFact.PageFactory.verifyTitle();
	}

	@When("^user come to  payment page$")
	public void user_come_to_payment_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user validates card holder name$")
	public void user_validates_card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.button);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.insertKeys("Shristi Himmat",ElementLocator.ElementLocator.cardHolderName);
	}

	@When("^user validates debit card number$")
	public void user_validates_debit_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.button);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.insertKeys("7451254814523",ElementLocator.ElementLocator.cardNumber);
	}

	@When("^user validates cvv$")
	public void user_validates_cvv() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.button);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.insertKeys("456",ElementLocator.ElementLocator.cvv);
	}

	@When("^user validates expiration month$")
	public void user_validates_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.button);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.insertKeys("02",ElementLocator.ElementLocator.expiryMon);
	}

	@When("^user validates expiration year$")
	public void user_validates_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.button);
		PageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		PageFact.PageFactory.insertKeys("2024",ElementLocator.ElementLocator.expiryYear);
	}

	@Then("^click on Make Payment$")
	public void click_on_Make_Payment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		PageFact.PageFactory.clickMethod(ElementLocator.ElementLocator.button);
	}

	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFact.PageFactory.closeBrowser();

	}
	


}
