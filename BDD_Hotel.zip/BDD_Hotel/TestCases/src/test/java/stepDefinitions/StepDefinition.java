package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementLocators.ElementLocator;

public class StepDefinition {
	@Given("^Login Page$")
	public void login_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.openbrowser();
		
	}

	@When("^User come to login page$")
	public void user_come_to_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.linkOpenLogin("file:///C:/Users/shimmats/Downloads/Hotel%20booking%20case%20study/login.html",ElementLocator.loginTitle);
		
	}

	@When("^Input username$")
	public void input_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("capgemini",ElementLocator.userName);
		
	}

	@When("^Input password$")
	public void input_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("capg1234",ElementLocator.password);
	}

	@Then("^Click on Login button$")
	public void click_on_Login_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
	}
	
	//Hotel booking form
	@Given("^hotel booking form$")
	public void hotel_booking_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.verifyTitle();
	}

	@When("^user validate FirstName$")
	public void user_validate_FirstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("Mayank",ElementLocator.firstName);
	}

	@When("^user validate LastName$")
	public void user_validate_LastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("Sharma",ElementLocator.lastName);
	}

	@When("^user validate Email$")
	public void user_validate_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.insertKeys("mayanksharma",ElementLocator.email);
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.clearBox(ElementLocator.email);
		pageFact.PageFactory.insertKeys("mayanksharma@gmail.com",ElementLocator.email);
	}

	@When("^user validate Mobile$")
	public void user_validate_Mobile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.insertKeys("1234",ElementLocator.mobile);
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.clearBox(ElementLocator.mobile);
		pageFact.PageFactory.insertKeys("9879879879",ElementLocator.mobile);
	}

	@When("^user validate Address$")
	public void user_validate_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.insertKeys("Capgemini, Sipcot, Siruseri, Chennai",ElementLocator.address);
	}

	@When("^user select city$")
	public void user_select_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.select(ElementLocator.city);
	}

	@When("^user select state$")
	public void user_select_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.select(ElementLocator.state);
	}

	@When("^user select number of guests$")
	public void user_select_number_of_guests() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.select(ElementLocator.persons);
	}

	@When("^user validates card holder name$")
	public void user_validates_card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("Mayank Sharma",ElementLocator.cardHolderName);
	}

	@When("^user validates card number$")
	public void user_validates_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("7451254814523",ElementLocator.cardNumber);
	}

	@When("^user validates cvv$")
	public void user_validates_cvv() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("456",ElementLocator.cvv);
	}

	@When("^user validates expiration month$")
	public void user_validates_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("02",ElementLocator.expiryMon);
	}

	@When("^user validates expiration year$")
	public void user_validates_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("2024",ElementLocator.expiryYear);
	}

	@Then("^click on confirm booking$")
	public void click_on_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		pageFact.PageFactory.clickMethod(ElementLocator.bookButton);
	}
}
