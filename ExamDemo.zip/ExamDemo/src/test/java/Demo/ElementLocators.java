package Demo;

import org.openqa.selenium.By;

public class ElementLocators {
	public static By Username=By.xpath("//input[@name='userName']");
	public static By Password=By.xpath("//input[@name='userPwd']");
	public static By login=By.xpath("//input[@value='Login']");
	public static By FirstName=By.id("txtFirstName");
	public static By LastName=By.xpath("//input[@name='txtLN']");
	public static By Email=By.xpath("//input[@name='Email']");
	public static By Phone=By.xpath("//input[@name='Phone']");
	public static By Address=By.xpath("//textarea[@rows='5']");
	public static By City=By.xpath("//select[@name='city']");
	public static By State=By.xpath("//select[@name='state']");
	public static By Number_of_guest_staying=By.xpath("//select[@name='persons']");
	public static By No_of_rooms_booked=By.id("rooms");
	public static By Card_Holder_Name=By.id("txtCardholderName");
	public static By Debit_Card_Number=By.id("txtDebit");
	public static By CVV=By.id("txtCvv");
	public static By Expiration_Month=By.id("txtMonth");
	public static By Expiration_Year=By.id("txtYear");
	public static By Confirm_Booking=By.xpath("//input[@value='Confirm Booking']");
	


}
